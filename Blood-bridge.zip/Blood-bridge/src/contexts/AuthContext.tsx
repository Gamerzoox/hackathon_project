import React, { createContext, useContext, useState, useEffect } from 'react';
import type { User } from '../types';

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, userType: 'donor' | 'hospital') => Promise<void>;
  register: (userData: any) => Promise<void>;
  logout: () => void;
  loading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const storedUser = localStorage.getItem('bloodbridge_user');
    if (storedUser) {
      try {
        setUser(JSON.parse(storedUser));
      } catch (error) {
        console.error('Error parsing stored user:', error);
        localStorage.removeItem('bloodbridge_user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email: string, password: string, userType: 'donor' | 'hospital') => {
    setLoading(true);
    try {
      const mockUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        email,
        userType,
        profile: userType === 'donor'
          ? {
              id: '1',
              userId: '1',
              firstName: 'John',
              lastName: 'Doe',
              bloodGroup: 'O+',
              dateOfBirth: '1990-01-01',
              phone: '+1234567890',
              address: '123 Main St',
              city: 'New York',
              state: 'NY',
              zipCode: '10001',
              isAvailable: true,
              lastDonation: null,
              totalDonations: 5,
              badges: ['First Timer', 'Regular Donor'],
              donationStreak: 3
            }
          : {
              id: '1',
              userId: '1',
              hospitalName: 'City General Hospital',
              registrationNumber: 'HOSP001',
              contactPerson: 'Dr. Sarah Johnson',
              phone: '+1234567890',
              address: '456 Hospital Ave',
              city: 'New York',
              state: 'NY',
              zipCode: '10002',
              facilityType: 'hospital',
              verificationStatus: 'verified'
            },
        createdAt: new Date().toISOString()
      };

      setUser(mockUser);
      localStorage.setItem('bloodbridge_user', JSON.stringify(mockUser));
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData: any) => {
    setLoading(true);
    try {
      const mockUser: User = {
        id: Math.random().toString(36).substr(2, 9),
        email: userData.email,
        userType: userData.userType,
        profile: userData.profile,
        createdAt: new Date().toISOString()
      };

      setUser(mockUser);
      localStorage.setItem('bloodbridge_user', JSON.stringify(mockUser));
    } catch (error) {
      console.error('Registration error:', error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('bloodbridge_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
};