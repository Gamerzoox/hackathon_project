import React from 'react';
import { Calendar, MapPin, Award, Heart, Clock, Users, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { useAuth } from '../contexts/AuthContext';

export const DonorDashboard: React.FC = () => {
  const { user } = useAuth();
  const profile = user?.profile as any;

  const upcomingAppointments = [
    {
      id: 1,
      center: 'City Blood Center',
      date: '2025-01-20',
      time: '10:00 AM',
      address: '123 Health Ave, New York, NY'
    }
  ];

  const nearbyEmergencies = [
    {
      id: 1,
      hospital: 'General Hospital',
      bloodType: 'O+',
      urgency: 'High',
      distance: '2.3 miles',
      unitsNeeded: 3
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {profile?.firstName}!
          </h1>
          <p className="text-gray-600 mt-2">
            Thank you for being a life-saver. Here's your donation journey.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Donations</p>
                  <p className="text-2xl font-bold text-red-600">{profile?.totalDonations}</p>
                </div>
                <Heart className="h-8 w-8 text-red-400" fill="currentColor" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Current Streak</p>
                  <p className="text-2xl font-bold text-orange-600">{profile?.donationStreak}</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Blood Type</p>
                  <p className="text-2xl font-bold text-blue-600">{profile?.bloodGroup}</p>
                </div>
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <span className="text-blue-600 font-bold text-sm">{profile?.bloodGroup}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Status</p>
                  <p className={`text-sm font-medium ${profile?.isAvailable ? 'text-green-600' : 'text-red-600'}`}>
                    {profile?.isAvailable ? 'Available' : 'Unavailable'}
                  </p>
                </div>
                <div className={`w-3 h-3 rounded-full ${profile?.isAvailable ? 'bg-green-400' : 'bg-red-400'}`}></div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Left Column */}
          <div className="space-y-6">
            {/* Upcoming Appointments */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-semibold flex items-center">
                    <Calendar className="h-5 w-5 mr-2 text-red-600" />
                    Upcoming Appointments
                  </h2>
                  <Button size="sm">Book New</Button>
                </div>
              </CardHeader>
              <CardContent>
                {upcomingAppointments.length > 0 ? (
                  <div className="space-y-4">
                    {upcomingAppointments.map(appointment => (
                      <div key={appointment.id} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-medium text-gray-900">{appointment.center}</h3>
                            <div className="flex items-center text-sm text-gray-600 mt-1">
                              <Clock className="h-4 w-4 mr-1" />
                              {appointment.date} at {appointment.time}
                            </div>
                            <div className="flex items-center text-sm text-gray-600 mt-1">
                              <MapPin className="h-4 w-4 mr-1" />
                              {appointment.address}
                            </div>
                          </div>
                          <Button variant="outline" size="sm">Reschedule</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Calendar className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No upcoming appointments</p>
                    <Button className="mt-4">Schedule Donation</Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Achievement Badges */}
            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold flex items-center">
                  <Award className="h-5 w-5 mr-2 text-yellow-600" />
                  Your Achievements
                </h2>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {profile?.badges?.map((badge: string, index: number) => (
                    <div key={index} className="text-center p-4 bg-yellow-50 rounded-lg">
                      <Award className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                      <p className="text-sm font-medium text-gray-900">{badge}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Column */}
          <div className="space-y-6">
            {/* Emergency Requests */}
            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold flex items-center">
                  <Heart className="h-5 w-5 mr-2 text-red-600" />
                  Nearby Emergency Requests
                </h2>
              </CardHeader>
              <CardContent>
                {nearbyEmergencies.length > 0 ? (
                  <div className="space-y-4">
                    {nearbyEmergencies.map(emergency => (
                      <div key={emergency.id} className="border-l-4 border-red-500 bg-red-50 p-4 rounded-lg">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="font-medium text-gray-900">{emergency.hospital}</h3>
                            <p className="text-sm text-gray-600">
                              Needs {emergency.unitsNeeded} units of {emergency.bloodType}
                            </p>
                            <div className="flex items-center text-sm text-gray-600 mt-1">
                              <MapPin className="h-4 w-4 mr-1" />
                              {emergency.distance} away
                            </div>
                            <span className={`inline-block px-2 py-1 text-xs rounded-full mt-2 ${
                              emergency.urgency === 'High' ? 'bg-red-100 text-red-800' : 
                              'bg-yellow-100 text-yellow-800'
                            }`}>
                              {emergency.urgency} Priority
                            </span>
                          </div>
                          <Button size="sm" className="ml-4">Respond</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Heart className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500">No emergency requests in your area</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold">Quick Actions</h2>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-3">
                  <Button variant="outline" className="justify-start">
                    <MapPin className="h-4 w-4 mr-2" />
                    Find Donation Centers
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Calendar className="h-4 w-4 mr-2" />
                    Schedule Appointment
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Users className="h-4 w-4 mr-2" />
                    Invite Friends
                  </Button>
                  <Button variant="outline" className="justify-start">
                    <Heart className="h-4 w-4 mr-2" />
                    Update Availability
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};