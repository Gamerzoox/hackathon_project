import React, { useState } from 'react';
import { Building, Users, AlertTriangle, TrendingDown, Plus, Search, Filter } from 'lucide-react';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';
import { useAuth } from '../contexts/AuthContext';

export const HospitalDashboard: React.FC = () => {
  const { user } = useAuth();
  const profile = user?.profile as any;
  const [activeTab, setActiveTab] = useState('inventory');

  const bloodInventory = [
    { type: 'A+', current: 25, minimum: 30, expiring: 3, status: 'low' },
    { type: 'A-', current: 18, minimum: 20, expiring: 1, status: 'low' },
    { type: 'B+', current: 35, minimum: 25, expiring: 2, status: 'good' },
    { type: 'B-', current: 12, minimum: 15, expiring: 0, status: 'critical' },
    { type: 'AB+', current: 8, minimum: 10, expiring: 1, status: 'low' },
    { type: 'AB-', current: 5, minimum: 8, expiring: 0, status: 'critical' },
    { type: 'O+', current: 45, minimum: 40, expiring: 4, status: 'good' },
    { type: 'O-', current: 20, minimum: 25, expiring: 2, status: 'low' },
  ];

  const emergencyRequests = [
    {
      id: 1,
      bloodType: 'O-',
      unitsNeeded: 5,
      patient: 'Emergency Surgery',
      priority: 'Critical',
      timeCreated: '10 minutes ago',
      responses: 3
    },
    {
      id: 2,
      bloodType: 'A+',
      unitsNeeded: 2,
      patient: 'Trauma Case',
      priority: 'High',
      timeCreated: '25 minutes ago',
      responses: 7
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'critical': return 'text-red-600 bg-red-100';
      case 'low': return 'text-yellow-600 bg-yellow-100';
      case 'good': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Critical': return 'text-red-600 bg-red-100';
      case 'High': return 'text-orange-600 bg-orange-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      default: return 'text-green-600 bg-green-100';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center">
            <Building className="h-8 w-8 mr-3 text-red-600" />
            {profile?.hospitalName}
          </h1>
          <p className="text-gray-600 mt-2">
            Real-time blood inventory management and emergency response dashboard
          </p>
        </div>

        {/* Alert Banner */}
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
          <div className="flex items-center">
            <AlertTriangle className="h-5 w-5 text-red-600 mr-3" />
            <div className="flex-1">
              <h3 className="text-red-800 font-medium">Critical Blood Shortage Alert</h3>
              <p className="text-red-700 text-sm">B- and AB- blood types are critically low. Consider sending emergency requests.</p>
            </div>
            <Button size="sm" className="ml-4">Send Alert</Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Inventory</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {bloodInventory.reduce((sum, item) => sum + item.current, 0)} units
                  </p>
                </div>
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <TrendingDown className="h-5 w-5 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Critical Types</p>
                  <p className="text-2xl font-bold text-red-600">
                    {bloodInventory.filter(item => item.status === 'critical').length}
                  </p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-400" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Active Requests</p>
                  <p className="text-2xl font-bold text-orange-600">{emergencyRequests.length}</p>
                </div>
                <div className="w-8 h-8 bg-orange-100 rounded-full flex items-center justify-center">
                  <Users className="h-5 w-5 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Expiring Soon</p>
                  <p className="text-2xl font-bold text-yellow-600">
                    {bloodInventory.reduce((sum, item) => sum + item.expiring, 0)}
                  </p>
                </div>
                <div className="w-8 h-8 bg-yellow-100 rounded-full flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tab Navigation */}
        <div className="border-b border-gray-200 mb-6">
          <nav className="-mb-px flex space-x-8">
            <button
              onClick={() => setActiveTab('inventory')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'inventory'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Blood Inventory
            </button>
            <button
              onClick={() => setActiveTab('requests')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'requests'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Emergency Requests
            </button>
            <button
              onClick={() => setActiveTab('donors')}
              className={`py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === 'donors'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              Donor Management
            </button>
          </nav>
        </div>

        {/* Tab Content */}
        {activeTab === 'inventory' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Blood Inventory Overview</h2>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                Update Inventory
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {bloodInventory.map((blood) => (
                <Card key={blood.type} hoverable>
                  <CardContent>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-gray-900 mb-2">
                        {blood.type}
                      </div>
                      <div className="text-2xl font-bold text-red-600 mb-2">
                        {blood.current} units
                      </div>
                      <div className="text-sm text-gray-600 mb-3">
                        Min: {blood.minimum} units
                      </div>
                      <div className={`inline-block px-2 py-1 text-xs rounded-full font-medium mb-2 ${getStatusColor(blood.status)}`}>
                        {blood.status.charAt(0).toUpperCase() + blood.status.slice(1)}
                      </div>
                      {blood.expiring > 0 && (
                        <div className="text-xs text-yellow-600">
                          {blood.expiring} expiring soon
                        </div>
                      )}
                      <div className="mt-3">
                        <Button size="sm" variant="outline" className="w-full">
                          Update
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'requests' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Emergency Blood Requests</h2>
              <Button>
                <Plus className="h-4 w-4 mr-2" />
                New Request
              </Button>
            </div>

            <div className="flex gap-4">
              <div className="flex-1">
                <Input placeholder="Search requests..." />
              </div>
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
            </div>

            <div className="space-y-4">
              {emergencyRequests.map((request) => (
                <Card key={request.id}>
                  <CardContent>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <span className="text-2xl font-bold text-red-600">
                            {request.bloodType}
                          </span>
                          <span className={`px-2 py-1 text-xs rounded-full font-medium ${getPriorityColor(request.priority)}`}>
                            {request.priority} Priority
                          </span>
                          <span className="text-sm text-gray-600">
                            {request.timeCreated}
                          </span>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-gray-700">Units Needed:</span>
                            <span className="ml-2 text-gray-600">{request.unitsNeeded}</span>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">Patient:</span>
                            <span className="ml-2 text-gray-600">{request.patient}</span>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">Donor Responses:</span>
                            <span className="ml-2 text-green-600 font-medium">{request.responses}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <Button size="sm">View Responses</Button>
                        <Button size="sm" variant="outline">Edit</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'donors' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Donor Management</h2>
              <Button>
                <Search className="h-4 w-4 mr-2" />
                Find Donors
              </Button>
            </div>

            <Card>
              <CardContent>
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500 mb-4">Donor management system coming soon</p>
                  <p className="text-sm text-gray-400">
                    This feature will allow you to view registered donors, send targeted requests,
                    and manage donor relationships.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};