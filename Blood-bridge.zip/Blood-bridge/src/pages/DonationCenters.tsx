import React, { useState } from 'react';
import { MapPin, Clock, Phone, Mail, Star, Navigation, Filter, Search, Heart, Award, Users, Calendar } from 'lucide-react';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input } from '../components/ui/Input';

interface DonationCenter {
  id: string;
  name: string;
  tagline: string;
  mission: string;
  description: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  email: string;
  website: string;
  rating: number;
  reviewCount: number;
  distance: string;
  operatingHours: {
    [key: string]: string;
  };
  services: string[];
  specialties: string[];
  achievements: string[];
  impactStats: {
    livesImpacted: string;
    unitsCollected: string;
    yearsServing: string;
  };
  features: string[];
  bloodTypes: string[];
  nextAvailableSlot: string;
  image: string;
}

const donationCenters: DonationCenter[] = [
  {
    id: '1',
    name: 'LifeStream Blood Center',
    tagline: 'Every Drop Counts, Every Life Matters',
    mission: 'To ensure a safe, adequate blood supply for our community through compassionate donor care and cutting-edge medical technology.',
    description: 'LifeStream Blood Center has been the cornerstone of blood donation services in the metropolitan area for over 30 years. We specialize in whole blood, platelet, and plasma donations with state-of-the-art equipment and highly trained medical staff.',
    address: '2847 Medical Plaza Drive',
    city: 'San Francisco',
    state: 'CA',
    zipCode: '94102',
    phone: '(415) 555-LIFE',
    email: 'donate@lifestream.org',
    website: 'www.lifestreamblood.org',
    rating: 4.8,
    reviewCount: 1247,
    distance: '0.8 miles',
    operatingHours: {
      'Monday': '7:00 AM - 7:00 PM',
      'Tuesday': '7:00 AM - 7:00 PM',
      'Wednesday': '7:00 AM - 7:00 PM',
      'Thursday': '7:00 AM - 7:00 PM',
      'Friday': '7:00 AM - 6:00 PM',
      'Saturday': '8:00 AM - 4:00 PM',
      'Sunday': '9:00 AM - 3:00 PM'
    },
    services: ['Whole Blood Donation', 'Platelet Donation', 'Plasma Donation', 'Double Red Cell', 'Directed Donations'],
    specialties: ['Pediatric Blood Products', 'Rare Blood Types', 'Emergency Response', 'Mobile Blood Drives'],
    achievements: ['AABB Accredited', 'FDA Licensed', 'Community Choice Award 2024', 'Excellence in Patient Care'],
    impactStats: {
      livesImpacted: '125,000+',
      unitsCollected: '45,000',
      yearsServing: '32'
    },
    features: ['Free Health Screening', 'Comfortable Donor Lounges', 'Free Snacks & Beverages', 'Donor Rewards Program', 'Online Scheduling'],
    bloodTypes: ['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'],
    nextAvailableSlot: 'Today at 2:30 PM',
    image: 'https://images.pexels.com/photos/4386466/pexels-photo-4386466.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    id: '2',
    name: 'Heartland Regional Blood Services',
    tagline: 'Connecting Hearts, Saving Lives',
    mission: 'To provide life-saving blood products while fostering a culture of giving and community support through innovative donor experiences.',
    description: 'Heartland Regional Blood Services is a non-profit organization dedicated to meeting the transfusion needs of over 40 hospitals across the region. Our donor-centric approach ensures comfort and safety while maximizing the impact of every donation.',
    address: '1205 Wellness Boulevard',
    city: 'San Francisco',
    state: 'CA',
    zipCode: '94105',
    phone: '(415) 555-HEART',
    email: 'info@heartlandblood.org',
    website: 'www.heartlandblood.org',
    rating: 4.9,
    reviewCount: 892,
    distance: '1.2 miles',
    operatingHours: {
      'Monday': '6:30 AM - 8:00 PM',
      'Tuesday': '6:30 AM - 8:00 PM',
      'Wednesday': '6:30 AM - 8:00 PM',
      'Thursday': '6:30 AM - 8:00 PM',
      'Friday': '6:30 AM - 7:00 PM',
      'Saturday': '7:00 AM - 5:00 PM',
      'Sunday': '8:00 AM - 4:00 PM'
    },
    services: ['Whole Blood Donation', 'Apheresis Donations', 'Convalescent Plasma', 'Autologous Donations', 'Cord Blood Banking'],
    specialties: ['Cancer Patient Support', 'Trauma Response', 'Surgical Blood Management', 'Research Partnerships'],
    achievements: ['Joint Commission Certified', 'Platinum Donor Recognition', 'Innovation in Healthcare Award', 'Top Workplace 2024'],
    impactStats: {
      livesImpacted: '200,000+',
      unitsCollected: '67,500',
      yearsServing: '28'
    },
    features: ['Express Donation Process', 'VIP Donor Suites', 'Wellness Checks', 'Mobile App Integration', 'Flexible Scheduling'],
    bloodTypes: ['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'],
    nextAvailableSlot: 'Tomorrow at 10:00 AM',
    image: 'https://images.pexels.com/photos/4386467/pexels-photo-4386467.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    id: '3',
    name: 'Unity Blood & Tissue Center',
    tagline: 'United in Purpose, Committed to Life',
    mission: 'To advance healthcare through comprehensive blood and tissue services, research, and education while maintaining the highest standards of safety and quality.',
    description: 'Unity Blood & Tissue Center is a leading medical facility specializing in blood collection, processing, and distribution. We serve as a critical resource for emergency medicine, surgical procedures, and ongoing patient care across Northern California.',
    address: '3401 Research Park Way',
    city: 'San Francisco',
    state: 'CA',
    zipCode: '94158',
    phone: '(415) 555-UNITY',
    email: 'contact@unityblood.org',
    website: 'www.unitybloodcenter.org',
    rating: 4.7,
    reviewCount: 1156,
    distance: '2.1 miles',
    operatingHours: {
      'Monday': '7:00 AM - 6:00 PM',
      'Tuesday': '7:00 AM - 6:00 PM',
      'Wednesday': '7:00 AM - 6:00 PM',
      'Thursday': '7:00 AM - 6:00 PM',
      'Friday': '7:00 AM - 5:00 PM',
      'Saturday': '8:00 AM - 3:00 PM',
      'Sunday': 'Closed'
    },
    services: ['Blood Collection', 'Tissue Banking', 'HLA Typing', 'Immunohematology', 'Therapeutic Apheresis'],
    specialties: ['Bone Marrow Registry', 'Stem Cell Processing', 'Clinical Research', 'Laboratory Services'],
    achievements: ['CAP Accredited Laboratory', 'Research Excellence Award', 'Safety Innovation Leader', 'Community Impact Recognition'],
    impactStats: {
      livesImpacted: '95,000+',
      unitsCollected: '38,200',
      yearsServing: '25'
    },
    features: ['Research Participation', 'Educational Programs', 'Corporate Partnerships', 'Specialized Testing', 'Quality Assurance'],
    bloodTypes: ['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'],
    nextAvailableSlot: 'Today at 4:15 PM',
    image: 'https://images.pexels.com/photos/4386465/pexels-photo-4386465.jpeg?auto=compress&cs=tinysrgb&w=800'
  },
  {
    id: '4',
    name: 'Golden Gate Community Blood Bank',
    tagline: 'Your Neighborhood Heroes in Healthcare',
    mission: 'To strengthen our local community by providing accessible, high-quality blood donation services with personalized care and unwavering commitment to donor satisfaction.',
    description: 'Golden Gate Community Blood Bank is a locally-owned and operated facility that has been serving the Bay Area community for over two decades. We pride ourselves on creating a welcoming environment where donors feel valued and appreciated.',
    address: '892 Community Health Circle',
    city: 'San Francisco',
    state: 'CA',
    zipCode: '94110',
    phone: '(415) 555-GATE',
    email: 'hello@ggbloodbank.com',
    website: 'www.goldengatecommunityblood.com',
    rating: 4.6,
    reviewCount: 743,
    distance: '1.7 miles',
    operatingHours: {
      'Monday': '8:00 AM - 6:00 PM',
      'Tuesday': '8:00 AM - 6:00 PM',
      'Wednesday': '8:00 AM - 6:00 PM',
      'Thursday': '8:00 AM - 6:00 PM',
      'Friday': '8:00 AM - 5:00 PM',
      'Saturday': '9:00 AM - 2:00 PM',
      'Sunday': 'Closed'
    },
    services: ['Walk-in Donations', 'Scheduled Appointments', 'Group Donations', 'First-Time Donor Support', 'Donor Education'],
    specialties: ['Community Outreach', 'School Programs', 'Corporate Blood Drives', 'Donor Retention'],
    achievements: ['Local Business Excellence', 'Community Service Award', 'Donor Satisfaction Leader', 'Volunteer Recognition'],
    impactStats: {
      livesImpacted: '75,000+',
      unitsCollected: '28,900',
      yearsServing: '22'
    },
    features: ['Personalized Service', 'Community Events', 'Donor Appreciation', 'Local Partnerships', 'Flexible Hours'],
    bloodTypes: ['O+', 'O-', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-'],
    nextAvailableSlot: 'Tomorrow at 11:30 AM',
    image: 'https://images.pexels.com/photos/4386464/pexels-photo-4386464.jpeg?auto=compress&cs=tinysrgb&w=800'
  }
];

export const DonationCenters: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCenter, setSelectedCenter] = useState<DonationCenter | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'map'>('list');

  const filteredCenters = donationCenters.filter(center =>
    center.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    center.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
    center.services.some(service => service.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`h-4 w-4 ${i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Find Donation Centers Near You
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover trusted blood donation centers in your area. Each center is carefully vetted 
            to ensure the highest standards of safety, comfort, and professional care.
          </p>
        </div>

        {/* Search and Filters */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex-1 max-w-md">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <Input
                  placeholder="Search by name, location, or service..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-3">
              <Button
                variant={viewMode === 'list' ? 'primary' : 'outline'}
                onClick={() => setViewMode('list')}
              >
                List View
              </Button>
              <Button
                variant={viewMode === 'map' ? 'primary' : 'outline'}
                onClick={() => setViewMode('map')}
              >
                Map View
              </Button>
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
            </div>
          </div>
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-gray-600">
            Showing {filteredCenters.length} donation centers near San Francisco, CA
          </p>
        </div>

        {/* Centers List */}
        <div className="space-y-6">
          {filteredCenters.map((center) => (
            <Card key={center.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-300">
              <div className="md:flex">
                {/* Image */}
                <div className="md:w-1/3">
                  <img
                    src={center.image}
                    alt={center.name}
                    className="w-full h-48 md:h-full object-cover"
                  />
                </div>

                {/* Content */}
                <div className="md:w-2/3 p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h2 className="text-2xl font-bold text-gray-900 mb-1">{center.name}</h2>
                      <p className="text-red-600 font-medium italic mb-2">{center.tagline}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <div className="flex items-center">
                          {renderStars(center.rating)}
                          <span className="ml-2 font-medium">{center.rating}</span>
                          <span className="ml-1">({center.reviewCount} reviews)</span>
                        </div>
                        <div className="flex items-center">
                          <Navigation className="h-4 w-4 mr-1" />
                          {center.distance}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium mb-2">
                        Available: {center.nextAvailableSlot}
                      </div>
                      <Button size="sm">Book Appointment</Button>
                    </div>
                  </div>

                  {/* Mission */}
                  <p className="text-gray-700 mb-4 leading-relaxed">{center.mission}</p>

                  {/* Quick Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="h-4 w-4 mr-2 text-red-500" />
                      {center.address}, {center.city}, {center.state} {center.zipCode}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Phone className="h-4 w-4 mr-2 text-red-500" />
                      {center.phone}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Clock className="h-4 w-4 mr-2 text-red-500" />
                      Today: {center.operatingHours.Monday}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Mail className="h-4 w-4 mr-2 text-red-500" />
                      {center.email}
                    </div>
                  </div>

                  {/* Impact Stats */}
                  <div className="grid grid-cols-3 gap-4 mb-4 p-4 bg-red-50 rounded-lg">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">{center.impactStats.livesImpacted}</div>
                      <div className="text-xs text-gray-600">Lives Impacted</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">{center.impactStats.unitsCollected}</div>
                      <div className="text-xs text-gray-600">Units Collected</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-red-600">{center.impactStats.yearsServing}</div>
                      <div className="text-xs text-gray-600">Years Serving</div>
                    </div>
                  </div>

                  {/* Services */}
                  <div className="mb-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Services Offered:</h4>
                    <div className="flex flex-wrap gap-2">
                      {center.services.slice(0, 4).map((service, index) => (
                        <span
                          key={index}
                          className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium"
                        >
                          {service}
                        </span>
                      ))}
                      {center.services.length > 4 && (
                        <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded-full text-xs">
                          +{center.services.length - 4} more
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Achievements */}
                  <div className="mb-4">
                    <h4 className="font-semibold text-gray-900 mb-2">Achievements & Certifications:</h4>
                    <div className="flex flex-wrap gap-2">
                      {center.achievements.map((achievement, index) => (
                        <span
                          key={index}
                          className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full text-xs font-medium flex items-center"
                        >
                          <Award className="h-3 w-3 mr-1" />
                          {achievement}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex flex-wrap gap-3">
                    <Button>
                      <Calendar className="h-4 w-4 mr-2" />
                      Schedule Appointment
                    </Button>
                    <Button variant="outline">
                      <MapPin className="h-4 w-4 mr-2" />
                      Get Directions
                    </Button>
                    <Button variant="outline">
                      <Phone className="h-4 w-4 mr-2" />
                      Call Now
                    </Button>
                    <Button 
                      variant="ghost"
                      onClick={() => setSelectedCenter(center)}
                    >
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-12 text-center bg-red-600 text-white rounded-xl p-8">
          <Heart className="h-12 w-12 mx-auto mb-4" fill="currentColor" />
          <h2 className="text-3xl font-bold mb-4">Ready to Save Lives?</h2>
          <p className="text-xl mb-6 text-red-100">
            Every donation can save up to three lives. Find a center near you and make a difference today.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary">
              <Users className="h-5 w-5 mr-2" />
              Register as Donor
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-red-600">
              <Calendar className="h-5 w-5 mr-2" />
              Schedule First Donation
            </Button>
          </div>
        </div>
      </div>

      {/* Detailed Center Modal would go here */}
      {selectedCenter && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <h2 className="text-2xl font-bold">{selectedCenter.name}</h2>
                <Button variant="ghost" onClick={() => setSelectedCenter(null)}>
                  ×
                </Button>
              </div>
              {/* Detailed center information would be rendered here */}
              <p className="text-gray-600 mb-4">{selectedCenter.description}</p>
              <Button onClick={() => setSelectedCenter(null)}>Close</Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};