import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { Header } from './components/layout/Header';
import { Footer } from './components/layout/Footer';
import { ChatBot } from './components/ChatBot';
import { Landing } from './pages/Landing';
import { Login } from './pages/Login';
import { DonorDashboard } from './pages/DonorDashboard';
import { HospitalDashboard } from './pages/HospitalDashboard';
import { DonationCenters } from './pages/DonationCenters';

const ProtectedRoute: React.FC<{ children: React.ReactNode; userType?: 'donor' | 'hospital' }> = ({ 
  children, 
  userType 
}) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-red-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (userType && user.userType !== userType) {
    return <Navigate to={user.userType === 'donor' ? '/donor/dashboard' : '/hospital/dashboard'} replace />;
  }
  
  return <>{children}</>;
};

const DashboardRoute: React.FC = () => {
  const { user } = useAuth();
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  return user.userType === 'donor' ? <DonorDashboard /> : <HospitalDashboard />;
};

function AppContent() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main className="flex-1">
        <Routes>
          <Route path="/" element={user ? <DashboardRoute /> : <Landing />} />
          <Route path="/login" element={user ? <DashboardRoute /> : <Login />} />
          <Route 
            path="/donor/dashboard" 
            element={
              <ProtectedRoute userType="donor">
                <DonorDashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/hospital/dashboard" 
            element={
              <ProtectedRoute userType="hospital">
                <HospitalDashboard />
              </ProtectedRoute>
            } 
          />
          {/* Placeholder routes for future pages */}
          <Route path="/centers" element={<DonationCenters />} />
          <Route path="/emergency" element={<div className="p-8 text-center">Emergency Requests - Coming Soon</div>} />
          <Route path="/awareness" element={<div className="p-8 text-center">Awareness Hub - Coming Soon</div>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
      <Footer />
      <ChatBot />
    </div>
  );
}

function App() {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  );
}

export default App;