import React, { useState } from 'react';
import { Menu, X, Heart, User, LogOut } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { Button } from '../ui/Button';

export const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { user, logout } = useAuth();

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <div className="bg-red-600 p-2 rounded-lg">
              <Heart className="h-6 w-6 text-white" fill="currentColor" />
            </div>
            <span className="text-xl font-bold text-gray-900">BloodBridge</span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="/" className="text-gray-600 hover:text-red-600 transition-colors">Home</a>
            <a href="/centers" className="text-gray-600 hover:text-red-600 transition-colors">Donation Centers</a>
            <a href="/emergency" className="text-gray-600 hover:text-red-600 transition-colors">Emergency</a>
            <a href="/awareness" className="text-gray-600 hover:text-red-600 transition-colors">Learn</a>
          </nav>

          {/* User Actions */}
          <div className="hidden md:flex items-center space-x-4">
            {user ? (
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <User className="h-5 w-5 text-gray-600" />
                  <span className="text-sm text-gray-600">
                    {user.userType === 'donor' ? 
                      `${(user.profile as any).firstName} ${(user.profile as any).lastName}` : 
                      (user.profile as any).hospitalName
                    }
                  </span>
                </div>
                <Button variant="outline" size="sm" onClick={logout}>
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                <a href="/login" className="text-gray-600 hover:text-red-600 transition-colors">
                  Login
                </a>
                <Button size="sm">
                  Get Started
                </Button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4">
            <div className="space-y-3">
              <a href="/" className="block px-4 py-2 text-gray-600 hover:text-red-600 transition-colors">Home</a>
              <a href="/centers" className="block px-4 py-2 text-gray-600 hover:text-red-600 transition-colors">Donation Centers</a>
              <a href="/emergency" className="block px-4 py-2 text-gray-600 hover:text-red-600 transition-colors">Emergency</a>
              <a href="/awareness" className="block px-4 py-2 text-gray-600 hover:text-red-600 transition-colors">Learn</a>
              {user ? (
                <div className="px-4 py-2 space-y-2">
                  <div className="text-sm text-gray-600">
                    {user.userType === 'donor' ? 
                      `${(user.profile as any).firstName} ${(user.profile as any).lastName}` : 
                      (user.profile as any).hospitalName
                    }
                  </div>
                  <Button variant="outline" size="sm" onClick={logout} className="w-full">
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="px-4 py-2 space-y-2">
                  <a href="/login" className="block w-full text-center py-2 text-gray-600 hover:text-red-600 transition-colors">
                    Login
                  </a>
                  <Button size="sm" className="w-full">
                    Get Started
                  </Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </header>
  );
};