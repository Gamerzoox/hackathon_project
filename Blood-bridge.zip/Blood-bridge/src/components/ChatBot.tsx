import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Heart } from 'lucide-react';
import { Button } from './ui/Button';
import { clsx } from 'clsx';

interface Message {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

const PREDEFINED_RESPONSES = {
  'hello': 'Hello! I\'m BloodBridge AI. How can I help you today? I can assist with donation information, finding centers, or emergency procedures.',
  'donate': 'Great choice! To donate blood, you need to be 18-65 years old, weigh at least 110 lbs, and be in good health. Would you like me to help you find nearby donation centers?',
  'emergency': 'For blood emergencies, please contact your nearest hospital immediately. I can help you find emergency contacts or nearby medical facilities. Is this a medical emergency?',
  'centers': 'I can help you find donation centers near you. Please share your location or zip code, and I\'ll show you the nearest centers with their operating hours.',
  'requirements': 'Blood donation requirements: Age 18-65, weight 110+ lbs, good health, no recent travel to certain areas, no recent tattoos/piercings (within 12 months). Need more specific info?',
  'help': 'I can help you with: Finding donation centers, Understanding donation requirements, Emergency blood requests, Appointment booking, General blood donation questions. What would you like to know?'
};

export const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hi! I\'m your BloodBridge assistant. I can help you with donation information, finding centers, or emergency procedures. How can I help?',
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getBotResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();
    
    for (const [key, response] of Object.entries(PREDEFINED_RESPONSES)) {
      if (lowerMessage.includes(key)) {
        return response;
      }
    }
    
    // Default response
    return 'I understand you\'re asking about blood donation. While I can provide general information, for specific medical questions please consult with healthcare professionals. Is there something specific about donation I can help with?';
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate bot thinking time
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: getBotResponse(inputText),
        isBot: true,
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={clsx(
          'fixed bottom-6 right-6 w-14 h-14 rounded-full shadow-lg transition-all duration-300 z-50',
          'flex items-center justify-center',
          isOpen ? 'bg-gray-600 hover:bg-gray-700' : 'bg-red-600 hover:bg-red-700'
        )}
      >
        {isOpen ? (
          <X className="h-6 w-6 text-white" />
        ) : (
          <MessageCircle className="h-6 w-6 text-white" />
        )}
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-24 right-6 w-80 h-96 bg-white rounded-lg shadow-2xl border border-gray-200 flex flex-col z-40">
          {/* Header */}
          <div className="bg-red-600 text-white p-4 rounded-t-lg">
            <div className="flex items-center space-x-2">
              <Heart className="h-5 w-5" fill="currentColor" />
              <div>
                <h3 className="font-semibold">BloodBridge AI</h3>
                <p className="text-xs text-red-100">Always here to help</p>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((message) => (
              <div
                key={message.id}
                className={clsx(
                  'flex',
                  message.isBot ? 'justify-start' : 'justify-end'
                )}
              >
                <div
                  className={clsx(
                    'max-w-xs px-3 py-2 rounded-lg text-sm',
                    message.isBot
                      ? 'bg-gray-100 text-gray-800'
                      : 'bg-red-600 text-white'
                  )}
                >
                  {message.text}
                </div>
              </div>
            ))}
            
            {isTyping && (
              <div className="flex justify-start">
                <div className="bg-gray-100 px-3 py-2 rounded-lg">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.2s' }}></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-pulse" style={{ animationDelay: '0.4s' }}></div>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="border-t border-gray-200 p-3">
            <div className="flex space-x-2">
              <textarea
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Ask me anything about blood donation..."
                className="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent"
                rows={1}
              />
              <Button
                size="sm"
                onClick={handleSendMessage}
                disabled={!inputText.trim()}
                className="h-10 w-10 p-0"
              >
                <Send className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};