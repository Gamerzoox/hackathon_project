export interface User {
  id: string;
  email: string;
  userType: 'donor' | 'hospital';
  profile: DonorProfile | HospitalProfile;
  createdAt: string;
}

export interface DonorProfile {
  id: string;
  userId: string;
  firstName: string;
  lastName: string;
  bloodGroup: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  dateOfBirth: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  isAvailable: boolean;
  lastDonation: string | null;
  totalDonations: number;
  badges: string[];
  donationStreak: number;
}

export interface HospitalProfile {
  id: string;
  userId: string;
  hospitalName: string;
  registrationNumber: string;
  contactPerson: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  facilityType: 'hospital' | 'blood_bank' | 'clinic';
  verificationStatus: 'pending' | 'verified' | 'rejected';
}

export interface BloodInventory {
  id: string;
  hospitalId: string;
  bloodGroup: string;
  quantity: number;
  expiryDate: string;
  lastUpdated: string;
  minimumThreshold: number;
}

export interface DonationCenter {
  id: string;
  name: string;
  address: string;
  city: string;
  state: string;
  phone: string;
  operatingHours: string;
  availableSlots: string[];
  coordinates: {
    lat: number;
    lng: number;
  };
}

export interface EmergencyRequest {
  id: string;
  hospitalId: string;
  bloodGroup: string;
  unitsNeeded: number;
  urgencyLevel: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  contactPerson: string;
  contactPhone: string;
  location: string;
  createdAt: string;
  status: 'active' | 'fulfilled' | 'expired';
}

export interface Appointment {
  id: string;
  donorId: string;
  centerId: string;
  appointmentDate: string;
  timeSlot: string;
  status: 'scheduled' | 'completed' | 'cancelled';
  notes?: string;
}